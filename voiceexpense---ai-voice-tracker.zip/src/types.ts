export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  timestamp: number;
}

export type AppScreen = 'dashboard' | 'expenses' | 'stats';

export interface VoiceAction {
  action: 'ADD_EXPENSE' | 'NAVIGATE' | 'DELETE_EXPENSE' | 'UNKNOWN' | 'GREETING';
  data?: any;
  message?: string;
}
