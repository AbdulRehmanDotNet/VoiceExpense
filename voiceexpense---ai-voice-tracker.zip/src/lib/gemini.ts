import { GoogleGenAI, Type } from "@google/genai";
import { VoiceAction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function parseVoiceCommand(text: string, currentScreen: string): Promise<VoiceAction> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `The user said: "${text}". 
    Current screen: ${currentScreen}.
    Current Date: ${new Date().toLocaleDateString()}.
    
    The user might speak in English, Hindi, or Hinglish (e.g. "500 rupaye dinner ke liye add karo").
    Parse this into a structured action for an expense tracking app.
    Possible actions:
    1. ADD_EXPENSE: Use when user wants to add an expense. Data should include amount (number), category (e.g. Food, Transport, Rent, Shopping, Others), description (string), and date (ISO string, default to today).
    2. NAVIGATE: Use when user wants to go to a screen ('dashboard', 'expenses', 'stats').
    3. DELETE_EXPENSE: Use when user wants to delete. Data might include a description or 'target: last'.
    4. GREETING: Use for simple hellos or general talk.
    5. UNKNOWN: If you can't figure it out.

    Return ONLY JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          action: {
            type: Type.STRING,
            enum: ["ADD_EXPENSE", "NAVIGATE", "DELETE_EXPENSE", "GREETING", "UNKNOWN"],
          },
          data: {
            type: Type.OBJECT,
            properties: {
              amount: { type: Type.NUMBER },
              category: { type: Type.STRING },
              description: { type: Type.STRING },
              date: { type: Type.STRING },
              screen: { type: Type.STRING },
              target: { type: Type.STRING }
            }
          },
          message: { type: Type.STRING, description: "A short confirmation message to speak back to the user." }
        },
        required: ["action", "message"]
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}') as VoiceAction;
  } catch (e) {
    return { action: 'UNKNOWN', message: "I couldn't understand that command." };
  }
}
