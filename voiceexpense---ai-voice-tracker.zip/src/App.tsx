import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  Plus, 
  Trash2, 
  LayoutDashboard, 
  ListOrdered, 
  PieChart, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight,
  Wallet,
  History,
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Expense, AppScreen, VoiceAction } from './types';
import { parseVoiceCommand } from './lib/gemini';

// --- Components ---

const StatCard = ({ title, value, icon: Icon, color }: { title: string, value: string, icon: any, color: string }) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
    <div className={`p-3 rounded-xl ${color}`}>
      <Icon className="w-6 h-6 text-white" />
    </div>
    <div>
      <p className="text-sm text-slate-500 font-medium">{title}</p>
      <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
    </div>
  </div>
);

const ExpenseItem = ({ expense, onDelete }: { expense: Expense, onDelete: (id: string) => void, key?: any }) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, scale: 0.95 }}
    className="bg-white p-4 rounded-xl border border-slate-100 flex items-center justify-between hover:shadow-md transition-shadow"
  >
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 font-bold">
        {expense.category[0]}
      </div>
      <div>
        <h4 className="font-semibold text-slate-800">{expense.description}</h4>
        <div className="flex gap-2 text-xs text-slate-500">
          <span>{expense.category}</span>
          <span>•</span>
          <span>{new Date(expense.date).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
    <div className="flex items-center gap-4">
      <span className="font-bold text-slate-900">₹{expense.amount.toLocaleString()}</span>
      <button 
        onClick={() => onDelete(expense.id)}
        className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  </motion.div>
);

// --- Main App ---

export default function App() {
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('voice_expenses');
    return saved ? JSON.parse(saved) : [];
  });
  const [screen, setScreen] = useState<AppScreen>('dashboard');
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    localStorage.setItem('voice_expenses', JSON.stringify(expenses));
  }, [expenses]);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-IN'; // Support Indian English/Hindi context

      recognitionRef.current.onresult = (event: any) => {
        const current = event.results[event.results.length - 1][0].transcript;
        setTranscript(current);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
        
        switch (event.error) {
          case 'not-allowed':
            showFeedback("Microphone access denied. Please allow it in your browser settings.", 'error');
            break;
          case 'audio-capture':
            showFeedback("No microphone found. Please connect one and try again.", 'error');
            break;
          case 'network':
            showFeedback("Network error. Please check your connection.", 'error');
            break;
          default:
            showFeedback(`Speech error: ${event.error}. Please try again.`, 'error');
        }
      };
    } else {
      showFeedback("Voice recognition is not supported in this browser. Please use Chrome or Edge.", 'error');
    }
  }, []);

  const showFeedback = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setFeedback({ message, type });
    setTimeout(() => setFeedback(null), 4000);
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setTranscript('');
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  // Process the transcript when listening stops and we have text
  useEffect(() => {
    if (!isListening && transcript && !isProcessing) {
      handleVoiceCommand(transcript);
    }
  }, [isListening]);

  const handleVoiceCommand = async (text: string) => {
    setIsProcessing(true);
    try {
      const result = await parseVoiceCommand(text, screen);
      console.log('Voice Action:', result);

      switch (result.action) {
        case 'ADD_EXPENSE':
          if (result.data?.amount) {
            const newExpense: Expense = {
              id: Math.random().toString(36).substr(2, 9),
              amount: result.data.amount,
              category: result.data.category || 'Others',
              description: result.data.description || 'Voice Entry',
              date: result.data.date || new Date().toISOString(),
              timestamp: Date.now()
            };
            setExpenses(prev => [newExpense, ...prev]);
            showFeedback(result.message || "Expense added successfully!", 'success');
          }
          break;
        case 'NAVIGATE':
          if (result.data?.screen) {
            setScreen(result.data.screen as AppScreen);
            showFeedback(result.message || `Switched to ${result.data.screen}`, 'success');
          }
          break;
        case 'DELETE_EXPENSE':
          if (result.data?.target === 'last' && expenses.length > 0) {
            setExpenses(prev => prev.slice(1));
            showFeedback("Last expense deleted.", 'success');
          } else if (result.data?.description) {
            const index = expenses.findIndex(e => e.description.toLowerCase().includes(result.data.description.toLowerCase()));
            if (index !== -1) {
              setExpenses(prev => prev.filter((_, i) => i !== index));
              showFeedback(`Deleted expense: ${expenses[index].description}`, 'success');
            } else {
              showFeedback("Could not find that expense to delete.", 'error');
            }
          }
          break;
        case 'GREETING':
          showFeedback(result.message || "Hello! How can I help you today?", 'info');
          break;
        default:
          showFeedback(result.message || "I'm not sure how to do that.", 'info');
      }
    } catch (error) {
      console.error(error);
      showFeedback("Something went wrong processing your voice.", 'error');
    } finally {
      setIsProcessing(false);
      setTranscript('');
    }
  };

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const recentExpenses = expenses.slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-32">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">VoiceExpense</h1>
          </div>
          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setScreen('dashboard')}
              className={`p-2 rounded-lg transition-all ${screen === 'dashboard' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <LayoutDashboard className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setScreen('expenses')}
              className={`p-2 rounded-lg transition-all ${screen === 'expenses' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <ListOrdered className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setScreen('stats')}
              className={`p-2 rounded-lg transition-all ${screen === 'stats' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <PieChart className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {screen === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <StatCard 
                  title="Total Spent" 
                  value={`₹${totalExpenses.toLocaleString()}`} 
                  icon={ArrowUpRight} 
                  color="bg-rose-500" 
                />
                <StatCard 
                  title="Transactions" 
                  value={expenses.length.toString()} 
                  icon={History} 
                  color="bg-indigo-500" 
                />
              </div>

              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    <History className="w-5 h-5 text-slate-400" />
                    Recent Activity
                  </h2>
                  <button onClick={() => setScreen('expenses')} className="text-sm text-indigo-600 font-medium hover:underline">
                    View All
                  </button>
                </div>
                <div className="space-y-3">
                  {recentExpenses.length > 0 ? (
                    recentExpenses.map(e => (
                      <ExpenseItem key={e.id} expense={e} onDelete={(id) => setExpenses(prev => prev.filter(ex => ex.id !== id))} />
                    ))
                  ) : (
                    <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-200">
                      <p className="text-slate-400">No expenses yet. Try saying "Add 500 for lunch"</p>
                    </div>
                  )}
                </div>
              </section>
            </motion.div>
          )}

          {screen === 'expenses' && (
            <motion.div 
              key="expenses"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold">All Transactions</h2>
              <div className="space-y-3">
                {expenses.map(e => (
                  <ExpenseItem key={e.id} expense={e} onDelete={(id) => setExpenses(prev => prev.filter(ex => ex.id !== id))} />
                ))}
              </div>
            </motion.div>
          )}

          {screen === 'stats' && (
            <motion.div 
              key="stats"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold">Spending Insights</h2>
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-center">
                <PieChart className="w-16 h-16 text-slate-200 mx-auto mb-4" />
                <p className="text-slate-500">Visual charts coming soon! Try adding more data via voice.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Voice Control Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-slate-50 via-slate-50 to-transparent pointer-events-none">
        <div className="max-w-2xl mx-auto flex flex-col items-center gap-4 pointer-events-auto">
          
          {/* Feedback Toast */}
          <AnimatePresence>
            {feedback && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className={`px-4 py-2 rounded-full shadow-lg flex items-center gap-2 text-sm font-medium ${
                  feedback.type === 'success' ? 'bg-emerald-500 text-white' : 
                  feedback.type === 'error' ? 'bg-rose-500 text-white' : 
                  'bg-slate-800 text-white'
                }`}
              >
                {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : 
                 feedback.type === 'error' ? <AlertCircle className="w-4 h-4" /> : null}
                {feedback.message}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Transcript Preview */}
          <AnimatePresence>
            {(isListening || transcript) && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white/80 backdrop-blur-md px-6 py-3 rounded-2xl border border-slate-200 shadow-xl max-w-full text-center italic text-slate-600"
              >
                {transcript || "Listening..."}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Mic Button */}
          <div className="relative">
            {isListening && (
              <motion.div 
                animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute inset-0 bg-indigo-500 rounded-full"
              />
            )}
            <button 
              onClick={toggleListening}
              disabled={isProcessing}
              className={`relative w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-95 ${
                isListening ? 'bg-rose-500 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'
              } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isProcessing ? (
                <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin" />
              ) : isListening ? (
                <MicOff className="w-8 h-8" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </button>
          </div>
          
          <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">
            {isListening ? "Tap to Stop" : "Tap to Speak"}
          </p>
        </div>
      </div>
    </div>
  );
}
